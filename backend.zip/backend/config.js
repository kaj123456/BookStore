import "dotenv/config";

export const PORT = 5555;

export const mongoDBURL ="mongodb+srv://project:project123@fullstack.edf7pea.mongodb.net/?retryWrites=true&w=majority&appName=fullstack";
 
